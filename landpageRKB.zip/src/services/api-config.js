export const apiConfig = {
  baseURL: "https://web-production-e57d6.up.railway.app/leads",
}